package com.capgemini.contactbook.dao;
import java.util.List;

import com.igate.contactbook.bean.*;

import com.capgemini.contactbook.ui.*;
import com.capgemini.contactbook.exception.*;

import com.capgemini.contactbook.exception.ContactBookException;

import com.igate.contactbook.bean.EnquiryBean;
public interface ContactBookDao {
	public String addEnquiryDetails(EnquiryBean enquirybean) throws ContactBookException;
	public List<EnquiryBean> retriveAllDetails()throws ContactBookException;
	public EnquiryBean viewEnquiryDetails(String enqryId) throws ContactBookException;
}


