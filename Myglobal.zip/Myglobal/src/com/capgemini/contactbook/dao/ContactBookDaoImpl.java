package com.capgemini.contactbook.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.dao.*;

import com.capgemini.contactbook.ui.*;
import com.capgemini.contactbook.exception.*;
import com.capgemini.contactbook.util.*;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.util.DBConnection;

import com.igate.contactbook.bean.EnquiryBean;

public class ContactBookDaoImpl implements ContactBookDao {
	
	Logger logger=Logger.getRootLogger();
	
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public String addEnquiryDetails(EnquiryBean enquirybean) throws ContactBookException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String enqryId=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, enquirybean.getfName());
			preparedStatement.setString(2,enquirybean.getlName());
			preparedStatement.setString(3, enquirybean.getcontactNo());
			preparedStatement.setString(4, enquirybean.getpDomain());
			preparedStatement.setString(5, enquirybean.getpLocation());
				
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ENQRYID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				enqryId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new ContactBookException("Inserting  details failed ");

			}
			else
			{
				logger.info(" Details added successfully:");
				return enqryId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
		
	}

	@Override
	public List<EnquiryBean> retriveAllDetails() throws ContactBookException {
		Connection con=DBConnection.getInstance().getConnection();
		int enqryCount = 0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<EnquiryBean> enquiryList=new ArrayList<EnquiryBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			while(resultset.next())
			{	
				EnquiryBean bean=new EnquiryBean();
				bean.setfName(resultset.getString(1));
				bean.setlName(resultset.getString(2));
				bean.setcontactNo(resultset.getString(3));
				bean.setpDomain(resultset.getString(4));
				bean.setpLocation(resultset.getString(5));
				enquiryList.add(bean);
				enqryCount++;
	}
}
		catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
		if( enqryCount == 0)
			return null;
		else
			return enquiryList;
	}

	@Override
	public EnquiryBean viewEnquiryDetails(String enqryId) throws ContactBookException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
	EnquiryBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_ENQUIRY_DETAILS_QUERY);
			preparedStatement.setString(1,enqryId);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean=new EnquiryBean();
				bean.setfName(resultset.getString(1));
				bean.setlName(resultset.getString(2));
				bean.setcontactNo(resultset.getString(3));
				bean.setpDomain(resultset.getString(4));
				bean.setpLocation(resultset.getString(5));
				
				
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		
	}
	}