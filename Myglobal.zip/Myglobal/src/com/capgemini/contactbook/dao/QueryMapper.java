package com.capgemini.contactbook.dao;

public interface QueryMapper {

	public static final String RETRIVE_ALL_QUERY="SELECT firstName,lastName,contactNo,domain, city FROM Enquiry";
	public static final String VIEW_ENQUIRY_DETAILS_QUERY="SELECT firstName,lastName,contactNo,domain,city FROM Enquiry WHERE enqryId=?";
	public static final String INSERT_QUERY="INSERT INTO Enquiry VALUES(enqryId_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String ENQRYID_QUERY_SEQUENCE="SELECT enqryId_sequence.CURRVAL FROM DUAL";
	
	
}