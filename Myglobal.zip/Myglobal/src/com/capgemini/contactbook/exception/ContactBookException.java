package com.capgemini.contactbook.exception;

public class ContactBookException extends Exception {
private static final long serialVersionUID = 726264577455921591L;
	public ContactBookException(String message) 
	{
		
		super(message);
	}

}
