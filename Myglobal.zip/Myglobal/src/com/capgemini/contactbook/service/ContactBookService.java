package com.capgemini.contactbook.service;

import java.util.List;

import com.igate.contactbook.bean.*;

import com.capgemini.*;
import com.capgemini.contactbook.exception.*;

import com.capgemini.contactbook.exception.ContactBookException;

import com.igate.contactbook.bean.EnquiryBean;


public interface ContactBookService {
	public String addEnquiryDetails(EnquiryBean enquirybean) throws ContactBookException;
	public EnquiryBean viewEnquiryDetails(String enqryId) throws ContactBookException;
	public List<EnquiryBean> retriveAll()throws ContactBookException;
}
