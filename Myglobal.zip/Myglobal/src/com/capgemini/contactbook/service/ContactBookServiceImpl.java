package com.capgemini.contactbook.service;

import com.capgemini.contactbook.exception.*;
import com.capgemini.contactbook.ui.*;
import com.capgemini.contactbook.exception.*;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;

import com.igate.contactbook.bean.EnquiryBean;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public  class ContactBookServiceImpl implements ContactBookService {
	
	ContactBookDao enquirydao;
	
	public String addEnquiryDetails(EnquiryBean enquirybean) throws ContactBookException {
		
		enquirydao= new ContactBookDaoImpl();
		String enqryId_sequence;
		enqryId_sequence= enquirydao.addEnquiryDetails(enquirybean);
		return enqryId_sequence;
	}
	
	
		public void validateEnquiry(EnquiryBean bean) throws Exception
		{
			List<String> validationErrors = new ArrayList<String>();

			//Validating fname
			if(!(isValidfName(bean.getfName()))) {
				validationErrors.add("\n Employee first Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			//Validating lname
			if(!(isValidlName(bean.getlName()))) {
				validationErrors.add("\n Employee first Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			
			
			//Validating Phone Number
			if(!(isValidcontactNo(bean.getcontactNo()))){
				validationErrors.add("\n Phone Number Should be in 10 digit \n");
			}
			//Validating pLocation
			if(!(isValidpLocation(bean.getpLocation()))) {
				validationErrors.add("\n should be alphabets  \n");
			}
			//validating pDomain
			if(!(isValidpDomain(bean.getpDomain()))) {
				validationErrors.add("\n should be in alphabets \n");
			}
					
		
			if(!validationErrors.isEmpty())
				throw new ContactBookException(validationErrors +"");
		}

		public boolean isValidfName(String fname){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(fname);
			return nameMatcher.matches();
		}
		
		public boolean isValidlName(String lname){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(lname);
			return nameMatcher.matches();
		}
		  
		public boolean isValidcontactNo(String contactNo){
			Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(contactNo);
			return phoneMatcher.matches();
			
		}
		public boolean isValidpDomain(String pDoamin){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(pDoamin);
			return nameMatcher.matches();
		}
		public boolean isValidpLocation(String pLocation){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(pLocation);
			return nameMatcher.matches();
		}
		
		public boolean validateEnqryId(String enqry_id) {
			
			Pattern idPattern = Pattern.compile("[0-9]{1,4}");
			Matcher idMatcher = idPattern.matcher(enqry_id);
			
			if(idMatcher.matches())
				return true;
			else
				return false;		
		}


		@Override
		
			public List<EnquiryBean> retriveAll() throws ContactBookException {
				enquirydao=new ContactBookDaoImpl();
				List<EnquiryBean> enquiryList=null;
				enquiryList=enquirydao.retriveAllDetails();
				return enquiryList;
			}
		public EnquiryBean viewEnquiryDetails(String enqryId) throws ContactBookException {
			enquirydao=new ContactBookDaoImpl();
			EnquiryBean bean=null;
			bean=enquirydao.viewEnquiryDetails(enqryId);
			return bean;
		}
}


		