package com.capgemini.contactbook.test;  

import static org.junit.Assert.*;
import org.junit.*;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;

import com.igate.contactbook.bean.EnquiryBean;


public class EnquirydaoTest {

    static ContactBookDaoImpl dao;
    static EnquiryBean enquirybean;

    @BeforeClass
    public static void initialize() {
        dao = new ContactBookDaoImpl();
        enquirybean = new EnquiryBean();
    }

    @Test
    public void testAddEnquiryDetails() throws ContactBookException {

        assertNotNull(dao.addEnquiryDetails(enquirybean));
    }
    
    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddEnquiryDetails1() throws ContactBookException {
        assertEquals(1007, dao.addEnquiryDetails(enquirybean));
    }

    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Test
    public void testAddEnquiryDetails2() throws ContactBookException {
        
    	enquirybean.setfName("com");
    	enquirybean.setlName("comm");
    	enquirybean.setcontactNo("9000342237");
    	enquirybean.setpDomain("java");
    	enquirybean.setpLocation("pune");
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addEnquiryDetails(enquirybean)) > 1000);

    }
}