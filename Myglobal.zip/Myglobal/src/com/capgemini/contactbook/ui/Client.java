package com.capgemini.contactbook.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.ui.*;
import com.capgemini.contactbook.service.*;
import com.capgemini.contactbook.exception.*;
import com.capgemini.contactbook.exception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

import com.igate.contactbook.bean.EnquiryBean;

import com.capgemini.contactbook.service.*;

import java.lang.NullPointerException;

@SuppressWarnings("unused")
public class Client  {

	static Scanner sc = new Scanner(System.in);
	static ContactBookService enquiryService = null;
	static ContactBookServiceImpl enquiryServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		EnquiryBean enquirybean = null;

		String enqryId = null;
		int option = 0;

		while (true) {

			// show menu
			
			System.out.println();
			System.out.println();
			System.out.println("   ******Global  Recruitments******** ");
			System.out.println("Choose an operation\n");

			System.out.println("1.Enter Enquiry Details");
		    System.out.println("2.Retrive all ");
			System.out.println("3. view  Enquiry Details on id ");
			System.out.println("0.Exit");
			System.out.println("--------------------------");
			
			
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (enquirybean  == null) {
						enquirybean   =  populateEnquirybean ();
						 System.out.println(enquirybean);
					}

					try {
						enquiryService = new ContactBookServiceImpl();
						enqryId = enquiryService.addEnquiryDetails(enquirybean);

						System.out.println("Details  has been stored successfully ");
						System.out.println("Enquiry  ID Is: " + enqryId);

					} catch (ContactBookException contactbookException) {
						logger.error("exception occured", contactbookException);
						System.out.println("ERROR : "
								+ contactbookException.getMessage());
					} finally {
						enqryId = null;
						enquiryService = null;
						enquirybean = null;
					}

					break;
				case 2:
				{
					enquiryService = new ContactBookServiceImpl();
					try {
						List<EnquiryBean> enquiryList = new ArrayList<EnquiryBean>();
						enquiryList = enquiryService.retriveAll();

						if (enquiryList != null) {
							Iterator<EnquiryBean> i = enquiryList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
									.println("Nobody, yet.");
						}

					}

					catch (ContactBookException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;
				}
				
				case 3:
				{
					enquiryServiceImpl = new ContactBookServiceImpl();

					System.out.println("Enter the Enquiry No ");
					enqryId = sc.next();

					while (true) {
						if (enquiryServiceImpl.validateEnqryId(enqryId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric employee id only, try again");
							enqryId = sc.next();
						}
					}

					enquirybean = getEnquiryDetails(enqryId);

					if (enquirybean != null) {
						System.out.println(" First Name:"
								+ enquirybean.getfName());
						System.out.println("Last Name:"
								+ enquirybean.getlName());
						System.out.println("Contact Number     :"
								+ enquirybean.getcontactNo());
						System.out.println("Preferred Domain       :"
								+ enquirybean.getpDomain());
						System.out.println("Preferred Location:"
								+ enquirybean.getpLocation());
						
					} else {
						System.err
								.println("There are no details associated with this id "
										+ enqryId);
					}

					break;

				}

				case 0:

					System.out.print("thankyou selecting us!!");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}  // end of while
	}
private static EnquiryBean getEnquiryDetails(String enqryId) {
		EnquiryBean enquiryBean = null;
		enquiryService = new ContactBookServiceImpl();

		try {
			enquiryBean = enquiryService.viewEnquiryDetails(enqryId);
		} catch (ContactBookException enquiryException) {
			logger.error("exception occured ", enquiryException);
			System.out.println("ERROR : " + enquiryException.getMessage());
		}

		enquiryService = null;
		return enquiryBean;
	}
private static EnquiryBean populateEnquirybean() throws Exception {

		
		EnquiryBean enquirybean = new EnquiryBean();

		
		System.out.println("Enter First name: ");
		enquirybean.setfName(sc.next());
		System.out.println("Enter Last name: ");
		enquirybean.setlName(sc.next());
		System.out.println("Enter Contact number: ");
		enquirybean.setcontactNo(sc.next());
		System.out.println("Enter Preferred Domain ");
		enquirybean.setpDomain(sc.next());
		System.out.println("Enter Preferred Location ");
		enquirybean.setpLocation(sc.next());
		
	
		
        enquiryServiceImpl = new ContactBookServiceImpl();


		try {
			enquiryServiceImpl.validateEnquiry(enquirybean);
			
			System.out.println("after validate enquiry");
			return enquirybean ;
		} catch (ContactBookException enquiryException) {
			logger.error("exception occured", enquiryException);
			System.err.println("Invalid data:");
			System.err.println(enquiryException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}

